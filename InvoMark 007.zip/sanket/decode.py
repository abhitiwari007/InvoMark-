from stegano import lsb


a = lsb.reveal('trail.png')
print(a)